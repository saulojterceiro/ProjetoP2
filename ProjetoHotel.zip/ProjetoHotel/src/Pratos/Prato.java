package Pratos;

import Comida.Comida;

public class Prato extends Comida{

	public Prato(String nome, double preco, String descri��o) {
		super(nome, preco, descri��o);
		// TODO Auto-generated constructor stub
	}
	

	
}
