package Quarto;

public class Presidencial extends Quarto{
	public Presidencial(String id) {
		super(id);
		this.setDiaria(450);
		// TODO Auto-generated constructor stub
	}
}
