package Quarto;

public class Luxo extends Quarto{
	public Luxo(String id) {
		super(id);
		this.setDiaria(250);
		// TODO Auto-generated constructor stub
	}
}
