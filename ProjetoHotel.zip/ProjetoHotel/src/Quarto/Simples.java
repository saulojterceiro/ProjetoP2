package Quarto;

public class Simples extends Quarto{
	public Simples(String id) {
		super(id);
		this.setDiaria(100);
		// TODO Auto-generated constructor stub
	}
}
