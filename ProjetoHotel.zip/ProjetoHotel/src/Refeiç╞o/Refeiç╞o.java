package Refei��o;

import java.util.ArrayList;

import Comida.Comida;
import Pratos.Prato;

public class Refei��o extends Comida{
	public Refei��o(String nome, double preco, String descri��o,ArrayList<Prato> pratos ) {
		super(nome, preco, descri��o);
		this.pratos = pratos;
		preco = this.getPreco();
	}

	private ArrayList<Prato> pratos;
	private String nome;
	private String descri��o;
	private double preco;
	
	public double getPreco(){
		return this.preco;
	}
	
	public boolean adicionarPrato(Prato prato){
		pratos.add(prato);
		return true;
	}
	
	
	public double calculaPreco(){
		double total = 0;
		for (int i = 0; i < pratos.size();i++){
			total = total + pratos.get(i).getPreco();
		}
		return total;
	}
	
	public String getNome(){
		return this.nome;
	}
	
	public String getDescri��o(){
		return this.descri��o;
	}
	

}
