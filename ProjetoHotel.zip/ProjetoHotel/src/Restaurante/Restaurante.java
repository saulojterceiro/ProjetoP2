package Restaurante;

import java.util.ArrayList;

import Comida.Comida;
import Hospede.Hospede;

public class Restaurante {

	private ArrayList<Comida> comidas;
	
	public boolean adicionarComida(Comida comida){
		this.comidas.add(comida);
		return true;
	}
	
	public boolean removerComida (Comida comida){
		if (comidas.contains(comida)){
			comidas.remove(comida);
			return true;
		}else{
			System.out.println("N�o existe tal refei��o no cardapio");
			return false;
		}
	}
	
	public boolean janta(Hospede hospede, Comida comida){
		hospede.adicionaGasto(comida.getPreco());
		return true;
	}
}
