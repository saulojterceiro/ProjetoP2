package Comida;

public class Comida {
	private String nome;
	private double preco;
	private String descri��o;
	
	public Comida(String nome, double preco, String descri��o){
		this.nome = nome;
		this.preco = preco;
		this.descri��o = descri��o;
	}

	public String getNome(){
		return this.nome;
	}
	
	public double getPreco(){
		return this.preco;
	}
	
	public String getDescri��o(){
		return this.descri��o;
	}
}
